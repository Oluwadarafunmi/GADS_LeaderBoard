package com.prosperekwerike.gadsleaderboard.network

data class LearningLeadersNetworkDataTranferObject(
    val name : String,
    val hours : Int,
    val country : String,
    val badgeUrl : String
)