package com.prosperekwerike.gadsleaderboard.domain

data class LearningLeadersCustomModel(
    val leaderName : String,
    val hoursAndCountry : String,
    val learningBadgeUrl : String
)