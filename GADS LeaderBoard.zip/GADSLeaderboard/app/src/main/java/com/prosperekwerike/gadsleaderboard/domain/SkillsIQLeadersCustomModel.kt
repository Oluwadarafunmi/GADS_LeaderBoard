package com.prosperekwerike.gadsleaderboard.domain

data class SkillsIQLeadersCustomModel(
    val leaderName : String,
    val leaderBadgeUrl : String,
    val leaderIQScoreAndCountry : String
)